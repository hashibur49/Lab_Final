﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket_Booking
{
    public partial class Signup : Form
    {
        public static string userid;
        public static string pass;
        public Signup()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (userIdlbl.Text == "" && passIdlbl.Text == "") 
            {
                MessageBox.Show("Please Enter Your User ID & Password");
            }

            else
            {
                userid = userIdlbl.Text;
                pass = passIdlbl.Text;
                Login lg = new Login();
                lg.Show();
                this.Hide();
            }

           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Booking_Ticket bt = new Booking_Ticket();
            bt.Show();
            this.Hide();
        }

        private void Signup_Load(object sender, EventArgs e)
        {

        }
    }
}
